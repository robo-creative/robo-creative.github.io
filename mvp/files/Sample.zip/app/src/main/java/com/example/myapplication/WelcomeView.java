package com.example.myapplication;

import com.robo.mvp.View;

public interface WelcomeView extends View {
    /**
     * Shows a message. The message content is decided by Presenter.
     */
    void showMessage(String message);
}