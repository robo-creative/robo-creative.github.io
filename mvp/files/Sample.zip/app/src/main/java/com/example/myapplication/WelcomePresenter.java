package com.example.myapplication;

import com.robo.mvp.AbstractPresenter;
import com.robo.mvp.View;

public class WelcomePresenter extends AbstractPresenter<WelcomeView> {

    @Override
    protected void onViewSet(final WelcomeView view) {
        view.getListeners().set(View.OnReadyListener.class, new View.OnReadyListener() {
            @Override
            public void onReady() {
                view.showMessage("Welcome to Robo MVP's world!");
            }
        });
    }
}