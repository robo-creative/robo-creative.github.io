package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;

import com.robo.mvp.AbstractActivity;
import com.robo.mvp.BindTo;

@BindTo(WelcomePresenter.class)
public class WelcomeActivity extends AbstractActivity implements WelcomeView {

    private TextView txtMessage;

    @Override
    protected void onInitLayout(Bundle savedInstanceState) {
        setContentView(R.layout.activity_welcome);
        txtMessage = (TextView)findViewById(R.id.txt_message);
    }

    @Override
    public void showMessage(String message) {
        txtMessage.setText(message);
    }
}