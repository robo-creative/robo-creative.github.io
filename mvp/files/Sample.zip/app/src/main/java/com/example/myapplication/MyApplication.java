package com.example.myapplication;

import android.app.Application;

import com.robo.mvp.Bootstrapper;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        new Bootstrapper().start();
    }
}